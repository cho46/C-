#include <stdio.h>
#pragma warning (disable : 4996)

int main()
{
	int i, j, k;



	for (i = 5; i >= 1; i--)
	{

		for (j = 1; j <= 5 - i; j++)
		{
			printf(" ");

		}
		for (k = 1; k <= i + i - 1; k++)
		{
			printf("*");
		}

		puts("");
	}


	return 0;
}