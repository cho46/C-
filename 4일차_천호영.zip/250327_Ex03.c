#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#pragma warning (disable : 4996)

int main()
{
	double a, b, c, x1, x2;
	double confirm;

	confirm = 0;

	printf("a�� �Է�: ");
	scanf("%lf", &a);
	while (getchar() != '\n');
	printf("b�� �Է�: ");
	scanf("%lf", &b);
	while (getchar() != '\n');
	printf("c�� �Է�: ");
	scanf("%lf", &c);
	while (getchar() != '\n');




	if (a == 0)
	{
		printf("a�� 0�� �Ǹ� �ȵ˴ϴ�.");
	}

	confirm = (b * b) - (4 * a * c);
	double root = sqrt(confirm);
	double min = b - (2 * b);

	if (confirm > 0)
	{
		x1 = (min + root) / (2 * a);
		x2 = (min - root) / (2 * a);

		printf("�Ǳ�: x = %.2lf or %.2lf", x1, x2);

	}
	else if (confirm == 0)
	{
		x1 = (-b / (2 * a));
		printf("�߱�: x = %.2lf", x1);

	}
	else
	{
		printf("�Ǳ��� �������� �ʽ��ϴ�.");
	}




	return 0;
}